package org.example.inviaggio;

public class LoginClienteController {

}

package dominio.scontistica;
import dominio.Corsa;
public interface PrezzoFinale {
    public float calcolaPrezzo(Corsa c);
}

package dominio;

public interface Observer {
    public void update(Observable o);
}

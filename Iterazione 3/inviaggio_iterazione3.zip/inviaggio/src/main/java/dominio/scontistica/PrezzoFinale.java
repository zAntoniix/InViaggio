package dominio.scontistica;

import dominio.Corsa;

public interface PrezzoFinale {
    float calcolaPrezzo(Corsa c);
}

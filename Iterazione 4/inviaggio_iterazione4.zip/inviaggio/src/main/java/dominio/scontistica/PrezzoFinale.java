package dominio.scontistica;

public interface PrezzoFinale {
    float calcolaPrezzo(Object o);
}
